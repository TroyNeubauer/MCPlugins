/**
 * Classes to facilitate {@link org.bukkit.World world} generation
 * implementation.
 */
package org.bukkit.generator;

