/**
 * Classes concerning the creation of boss bars that appear at the top of the
 * player's screen.
 */
package org.bukkit.boss;
