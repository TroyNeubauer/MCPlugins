/**
 * Multi and single purpose classes to facilitate various programmatic
 * concepts.
 */
package org.bukkit.util;

