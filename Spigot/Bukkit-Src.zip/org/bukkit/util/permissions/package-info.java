/**
 * Static methods for miscellaneous {@link org.bukkit.permissions.Permission
 * permission} functionality.
 */
package org.bukkit.util.permissions;

