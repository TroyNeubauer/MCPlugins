/**
 * Classes that allow attaching persistent data to various objects.
 */
package org.bukkit.persistence;
