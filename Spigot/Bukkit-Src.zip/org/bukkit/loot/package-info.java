/**
 * Classes relevant to loot table manipulation and generation.
 */
package org.bukkit.loot;
