/**
 * Classes relevant to specific material types.
 */
package org.bukkit.material.types;
