/**
 * Classes that represents various voxel types and states.
 */
package org.bukkit.material;

