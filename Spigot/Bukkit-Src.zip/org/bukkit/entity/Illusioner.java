package org.bukkit.entity;

/**
 * Represents an Illusioner "Illager".
 */
public interface Illusioner extends Spellcaster { }
