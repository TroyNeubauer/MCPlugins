package org.bukkit.entity;

/**
 * Represents a Stray - variant of {@link Skeleton}.
 */
public interface Stray extends Skeleton { }
