/**
 * Classes used to manipulate the default command and topic assistance system.
 */
package org.bukkit.help;

