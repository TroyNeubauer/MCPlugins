/**
 * Classes dedicated to providing a layer of plugin specified data on various
 * Minecraft concepts.
 */
package org.bukkit.metadata;

