/**
 * Classes that allow attaching custom data to items.
 */
package org.bukkit.inventory.meta.tags;
