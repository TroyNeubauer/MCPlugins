package org.bukkit.inventory;

/**
 * Interface to the inventory of a Grindstone.
 */
public interface GrindstoneInventory extends Inventory { }
