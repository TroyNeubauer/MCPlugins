package org.bukkit.inventory;

/**
 * Interface to the inventory of a Loom.
 */
public interface LoomInventory extends Inventory { }
