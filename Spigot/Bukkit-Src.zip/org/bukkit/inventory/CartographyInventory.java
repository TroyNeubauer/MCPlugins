package org.bukkit.inventory;

/**
 * Interface to the inventory of a Cartography table.
 */
public interface CartographyInventory extends Inventory { }
