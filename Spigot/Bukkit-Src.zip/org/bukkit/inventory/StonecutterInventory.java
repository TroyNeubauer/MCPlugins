package org.bukkit.inventory;

/**
 * Interface to the inventory of a Stonecutter.
 */
public interface StonecutterInventory extends Inventory { }
