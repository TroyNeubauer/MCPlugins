package org.bukkit.block;

/**
 * Represents a captured state of a conduit.
 */
public interface Conduit extends TileState { }
