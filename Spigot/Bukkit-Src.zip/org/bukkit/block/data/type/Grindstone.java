package org.bukkit.block.data.type;

import org.bukkit.block.data.Directional;
import org.bukkit.block.data.FaceAttachable;

public interface Grindstone extends Directional, FaceAttachable {
}
