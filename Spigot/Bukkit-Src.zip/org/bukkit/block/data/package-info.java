/**
 * Generalized BlockData classes.
 */
package org.bukkit.block.data;
