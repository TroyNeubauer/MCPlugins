package org.bukkit.block;

/**
 * Represents a captured state of a (possibly inverted) daylight detector.
 */
public interface DaylightDetector extends TileState { }
