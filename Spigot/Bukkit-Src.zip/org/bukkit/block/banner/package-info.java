/**
 * Classes relevant to banner blocks.
 */
package org.bukkit.block.banner;
