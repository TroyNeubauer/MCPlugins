package org.bukkit.block;

/**
 * Represents a captured state of an on / off comparator.
 */
public interface Comparator extends TileState { }
