package org.bukkit.block;

/**
 * Represents a captured state of a blast furnace.
 */
public interface BlastFurnace extends Furnace { }
