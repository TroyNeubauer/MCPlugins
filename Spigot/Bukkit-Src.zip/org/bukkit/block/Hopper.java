package org.bukkit.block;

import org.bukkit.loot.Lootable;

/**
 * Represents a captured state of a hopper.
 */
public interface Hopper extends Container, Lootable { }
