/**
 * Classes relating to handling specialized non-chat player input.
 */
package org.bukkit.command;

