/**
 * Commands for emulating the Minecraft commands and other necessary ones for
 * use by a Bukkit implementation.
 */
package org.bukkit.command.defaults;

